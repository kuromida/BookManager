package com.project;

import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.Font;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JTextField;
import java.awt.Color;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class FindIdpw {
	Font f_findid = new Font("����ü",Font.PLAIN,13);
	JDialog jdl_findid = new JDialog();
	JPanel jp_button = new JPanel();
	JPanel jp_findid = new JPanel();
	JButton jbtn_findid = new JButton("IDã��");
	JButton jbtn_findpw = new JButton("PWã��");
	JLabel jlb_findid_name = new JLabel("�̸�");
	JTextField jtf_findid_name = new JTextField();
	JLabel jlb_findid_hp = new JLabel("��ȭ��ȣ");
	JTextField jtf_findid_hp = new JTextField();
	JButton jbtn_findid_findid = new JButton("Ȯ��");
	
	JButton jbtn_findid_gologin = new JButton("���");
	
	JLabel jlb_findpw_id = new JLabel("���̵�");
	JTextField jtf_findpw_id = new JTextField();
	JLabel jlb_findpw_name = new JLabel("�̸�");
	JTextField jtf_findpw_name = new JTextField();
	JButton jbtn_findpw_findpw = new JButton("Ȯ��");	
	JPanel jp_findpw = new JPanel();
	JLabel jlb_findpw_hp = new JLabel("��ȭ��ȣ");
	JTextField jtf_findpw_hp = new JTextField();
	JButton jbtn_findpw_gologin = new JButton("���");
	public boolean isView=false;
	public String title="";
	
	
	
	
	FindIdpw(){
		
	}
	
	public void initDisplay(){
		jp_button.setBackground(Color.WHITE);
		jdl_findid.getContentPane().add(jp_button);
		jp_findid.setBackground(Color.WHITE);
		jdl_findid.getContentPane().add(jp_findid);
		jdl_findid.getContentPane().setBackground(Color.WHITE);
		jdl_findid.setSize(400, 550);	
		jdl_findid.setVisible(true);
		jdl_findid.getContentPane().setLayout(null);
		jdl_findid.setTitle("ID/PWã��");
		
		jtf_findid_hp.setBounds(33, 112, 158, 38);
		jtf_findid_hp.setColumns(10);
		
		jtf_findid_name.setBounds(33, 37, 158, 38);
		jtf_findid_name.setColumns(10);
						
		jp_button.setBounds(12, 10, 360, 85);
		
		jp_button.setLayout(null);
		jbtn_findpw.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				jp_findid.setVisible(false);
			
				jp_findpw.setVisible(true);				
			}
		});
		jp_button.add(jbtn_findpw);		
		jbtn_findid.setBounds(30, 10, 130, 40);
		
		jdl_findid.setResizable(false);
		
		jp_button.add(jbtn_findid);
		jbtn_findpw.setBounds(201, 10, 130, 40);
		jbtn_findid.setIcon(new ImageIcon("C:\\idã��.png"));				
		jbtn_findpw.setIcon(new ImageIcon("C:\\pwã��.png"));	
		
		jdl_findid.getContentPane().add(jp_findid);
		jp_findid.setBounds(12, 105, 360, 370);
		jp_findid.setLayout(null);
		jlb_findid_name.setBounds(33, 0, 81, 38);
		jlb_findid_name.setFont(f_findid);
		
		jp_findid.add(jlb_findid_name);
		
		jp_findid.add(jtf_findid_name);
		jlb_findid_hp.setBounds(33, 75, 81, 38);
		jlb_findid_hp.setFont(f_findid);
		
		jp_findid.add(jlb_findid_hp);
		
		jp_findid.add(jtf_findid_hp);
		jbtn_findid_findid.setBounds(33, 300, 130, 40);
		
		
		jp_findid.add(jbtn_findid_findid);
		jbtn_findid_findid.setIcon(new ImageIcon("C:\\idã��final.png"));
		jbtn_findid_gologin.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				jdl_findid.setVisible(false);
				
			}
		});
		jbtn_findid_gologin.setBounds(190, 300, 130, 40);
		
		jp_findid.add(jbtn_findid_gologin);
		jbtn_findid_gologin.setIcon(new ImageIcon("C:\\�α���ȭ���ư.png"));
												
	
	
	jtf_findpw_hp.setBounds(33, 185, 158, 38);
	jtf_findpw_hp.setColumns(10);
	jp_button.setBackground(Color.WHITE);
	jdl_findid.getContentPane().add(jp_button);
	jp_findpw.setBackground(Color.WHITE);
	jdl_findid.getContentPane().add(jp_findpw);
	jdl_findid.getContentPane().setBackground(Color.WHITE);
	jdl_findid.setSize(400, 550);	
	jdl_findid.setVisible(true);
	jdl_findid.getContentPane().setLayout(null);
	jdl_findid.setResizable(false);
	jdl_findid.setTitle("ID/PWã��");
	
	jtf_findpw_name.setBounds(33, 112, 158, 38);
	jtf_findpw_name.setColumns(10);
	
	jtf_findpw_id.setBounds(33, 37, 158, 38);
	jtf_findpw_id.setColumns(10);
					
	jp_button.setBounds(12, 10, 360, 85);
	
	jp_button.setLayout(null);
	jp_button.add(jbtn_findpw);
	jbtn_findid.addActionListener(new ActionListener() {
		public void actionPerformed(ActionEvent e) {
			jp_findpw.setVisible(false);
			JDialog jdl_findid = new JDialog();
			jp_findid.setVisible(true);
		}
	});
	
	jbtn_findid.setBounds(30, 10, 130, 40);
	
	jp_button.add(jbtn_findid);
	jbtn_findpw.setBounds(201, 10, 130, 40);
					
	jdl_findid.getContentPane().add(jp_findpw);
	jp_findpw.setBounds(12, 105, 360, 370);
	jp_findpw.setLayout(null);
	jlb_findpw_id.setBounds(33, 0, 81, 38);
	jlb_findpw_id.setFont(f_findid);
	
	jbtn_findid.setIcon(new ImageIcon("C:\\idã��.png"));				
	jbtn_findpw.setIcon(new ImageIcon("C:\\pwã��.png"));	
	
	jp_findpw.add(jlb_findpw_id);
	
	jp_findpw.add(jtf_findpw_id);
	jlb_findpw_name.setBounds(33, 76, 81, 38);
	jlb_findpw_name.setFont(f_findid);
	jp_findpw.add(jlb_findpw_name);
	
	jp_findpw.add(jtf_findpw_name);
	jbtn_findpw_findpw.setBounds(33, 300, 130, 40);
	jbtn_findpw_findpw.setIcon(new ImageIcon("C:\\pwã��final.png"));
	
	jp_findpw.add(jbtn_findpw_findpw);
	jlb_findpw_hp.setBounds(33, 148, 81, 38);
	jlb_findpw_hp.setFont(f_findid);
	jp_findpw.add(jlb_findpw_hp);
	
	jp_findpw.add(jtf_findpw_hp);
	jbtn_findpw_gologin.setBounds(190, 300, 130, 40);
	
	jp_findpw.add(jbtn_findpw_gologin);
	jbtn_findpw_gologin.setIcon(new ImageIcon("C:\\�α���ȭ���ư.png"));
	jbtn_findpw_gologin.addActionListener(new ActionListener() {
		public void actionPerformed(ActionEvent e) {
			jbtn_findpw_gologin.setVisible(false);
			
		}
	});
	
											
}

	
	public static void main(String[] args) {
	new FindIdpw();
	
	
	}
}
			
			
	
